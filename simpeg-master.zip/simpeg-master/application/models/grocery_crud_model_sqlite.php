<?php
class grocery_crud_model_SQLite extends grocery_CRUD_Generic_Model{

}
