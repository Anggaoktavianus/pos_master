<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
if(isset($cms_content)){
    echo $cms_content;
}