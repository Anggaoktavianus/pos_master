<?php
class grocery_crud_model_MySQL extends grocery_CRUD_Model{
	
}
