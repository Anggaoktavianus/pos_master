# simpeg
Contoh Sistem Kepegawaian Sederhana dengan Menggunakan Codeigniter

Supaya aplikasi ini dapat berjalan, sesuaikan pengaturan dibawah dengan nama folder anda :

* nama_folder/application/config/config.php line 42
* nama_folder/.htaccess line 4

username : admin password : admin